package jag_group_1.spring_jdbc_1;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class VehicleRowMapper implements RowMapper<Vehicle>
{

	public Vehicle mapRow(ResultSet rs, int rowNum) throws SQLException {
		Vehicle vehicle=new Vehicle();
		vehicle.setId(rs.getInt("id"));
		vehicle.setName(rs.getString(2));
		vehicle.setType(rs.getString(3));
		vehicle.setCompany(rs.getString(4));
		return vehicle;
	}
}