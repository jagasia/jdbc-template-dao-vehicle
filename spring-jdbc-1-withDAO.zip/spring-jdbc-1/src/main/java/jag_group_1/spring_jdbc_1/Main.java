package jag_group_1.spring_jdbc_1;

import java.util.List;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
		VehicleDAO vdao=(VehicleDAO) ctx.getBean("vdao");
		vdao.show();
//		List<Vehicle> vehicles = vdao.read();
//		for(Vehicle v:vehicles)
//			System.out.println(v);
		
//		Vehicle vehicle = vdao.read(150);
//		System.out.println(vehicle);
		System.out.println("Hello world llll");

//		int no=vdao.create(new Vehicle(152,"Ambassador","Good","Excellent"));
		
//		int no=vdao.update(new Vehicle(152,"Ambassador","Good","Old"));
		
//		int  no=vdao.delete(152);
//		System.out.println(no);
	}

}
