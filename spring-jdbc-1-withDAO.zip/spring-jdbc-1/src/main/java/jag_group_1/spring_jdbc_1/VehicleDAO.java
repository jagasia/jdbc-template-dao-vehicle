package jag_group_1.spring_jdbc_1;

import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;

public class VehicleDAO {
	private JdbcTemplate jt;
	
	public VehicleDAO() {}
	public VehicleDAO(JdbcTemplate jt) {
		super();
		this.jt = jt;
	}
	public JdbcTemplate getJt() {
		return jt;
	}
	public void setJt(JdbcTemplate jt) {
		this.jt = jt;
	}
	public int create(Vehicle vehicle)
	{
		return jt.update("INSERT INTO Vehicle VALUES(?, ?,?,?)",vehicle.getId(),vehicle.getName(),vehicle.getType(),vehicle.getCompany());
	}
	public List<Vehicle> read()
	{
		return jt.query("SELECT * FROM Vehicle", new VehicleRowMapper());
	}
	public Vehicle read(int id)
	{
		Vehicle vehicle=null;
		List<Vehicle> vehicles = jt.query("SELECT * FROM Vehicle WHERE id=?", new VehicleRowMapper(),id);
		if(vehicles.size()==1)
			vehicle=vehicles.get(0);
		return vehicle;
	}
	public int update(Vehicle vehicle)
	{
		return jt.update("UPDATE Vehicle SET name=?, type=?, company=? WHERE id=?",vehicle.getName(),vehicle.getType(),vehicle.getCompany(),vehicle.getId());
	}
	public int delete(int id)
	{
		return jt.update("DELETE FROM Vehicle WHERE id=?", id);		
	}
	
	public void show()
	{
		System.out.println("This is vehicle dao object");
	}
}
